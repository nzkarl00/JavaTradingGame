package game;
public class Main {

	public static void main(String[] args) {
		GameManager manager = new GameManager();
		manager.launchSetupWindow();
	}


}
