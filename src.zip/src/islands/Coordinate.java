package islands;
/**
 * Class to represent location of object on 2d grid
 * */

public class Coordinate {

	float x;
	float y;

}
